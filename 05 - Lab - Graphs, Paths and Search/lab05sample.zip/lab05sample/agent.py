import pyglet
from graphics import COLOUR_NAMES

class Agent:
    def __init__(self, world, idx, speed):
        self.world = world
        self.box = world.boxes[idx]
        self.speed = speed
        self.path = []
        self.target = None
        self.sprite = pyglet.shapes.Circle(
            self.box.center().x, self.box.center().y, 10,
            color=COLOUR_NAMES['BLUE'],
            batch=self.world.batch
        )

    def set_target(self, target_idx):
        self.target = self.world.boxes[target_idx]

    def plan_path(self):
        if self.target:
            self.path = self.world.find_path(self.box.index, self.target.index)
        else:
            self.path = []

    def update(self, dt):
        if self.path:
            next_box = self.world.boxes[self.path[0]]
            direction = next_box.center() - self.box.center()
            distance = direction.length()
            if distance <= self.speed * dt:
                self.box = next_box
                self.path.pop(0)
            else:
                direction.normalize()
                self.sprite.x += direction.x * self.speed * dt
                self.sprite.y += direction.y * self.speed * dt

class AgentType1(Agent):
    def __init__(self, world, idx, speed):
        super().__init__(world, idx, speed)
        self.sprite.color = COLOUR_NAMES['GREEN']

    def plan_path(self):
        if self.target:
            self.path = self.world.find_path(self.box.index, self.target.index, ignore_terrain=True)
        else:
            self.path = []

class AgentType2(Agent):
    def __init__(self, world, idx, speed):
        super().__init__(world, idx, speed)
        self.sprite.color = COLOUR_NAMES['RED']

    def plan_path(self):
        if self.target:
            # Use a different graph structure for path planning
            graph = self.world.generate_graph(terrain_costs={'WATER': 1, 'MUD': 5, 'SAND': 3})
            self.path = self.world.find_path(self.box.index, self.target.index, graph=graph)
        else:
            self.path = []